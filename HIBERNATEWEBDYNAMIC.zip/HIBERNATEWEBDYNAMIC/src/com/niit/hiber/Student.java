package com.niit.hiber;

public class Student {
	
	private int studentId;
	private String firstName;
	private String lastName;
	private String rollno;
	private int age;
	private StudentClass studentClass;

	public Student() {
	}
	
	public Student(/*int studentId,*/ String firstName, String lastName, String rollno, int age,
			StudentClass studentClass) {
		//super();
		//this.studentId = studentId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.rollno = rollno;
		this.age = age;
		this.studentClass = studentClass;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getRollno() {
		return rollno;
	}

	public void setRollno(String rollno) {
		this.rollno = rollno;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public StudentClass getStudentClass() {
		return studentClass;
	}

	public void setStudentClass(StudentClass studentClass) {
		this.studentClass = studentClass;
	}

}
